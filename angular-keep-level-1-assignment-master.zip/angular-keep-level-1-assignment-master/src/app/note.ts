export class Note {
    public title:string;
    public text:string;
    constructor(){
        this.title='';
        this.text='';
    }
}
