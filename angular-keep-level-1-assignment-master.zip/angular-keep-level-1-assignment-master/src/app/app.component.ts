import { Component, OnInit } from '@angular/core';
import {Note} from './note';
import { HttpClient } from '@angular/common/http';
import {NotesService} from './notes.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  public note:Note;
  public notes:Array<Note>;
  public errMessage:string;

  constructor(private notesService:NotesService) {
    this.note=new Note( );
    this.notes=[ ];
   }
   addnote(){
     if(this.note.title==='' || this.note.text===''){
       this.errMessage = 'Title and Text both are required fields';
     }else{
    // console.log("info"+this.note.title);
     this.notes.push(this.note);
     this.notesService.addNote(this.note).subscribe(
      data=> {
        
      },
     
     err=> {
     // console.log(err);
       this.errMessage = err.message;
       const noteIndex = this.notes.findIndex(note=>note.title === this.note.title);
       this.notes.splice(noteIndex,1);

     }
    );
    this.note = new Note();
  }
   }

  ngOnInit() {
    this.notesService.getNotes().subscribe(
      data=> {
        this.notes=data;
      },
      err=> {
       console.log(err);
        this.errMessage=err.message;
      }
    )
  }

}


