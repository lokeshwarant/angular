import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BsDropdownModule, TooltipModule, ModalModule, CollapseModule, AlertModule, ButtonsModule } from 'ngx-bootstrap';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    CollapseModule.forRoot(),
     AlertModule.forRoot(),
    ButtonsModule.forRoot(),
  ],
  exports: [BsDropdownModule, TooltipModule, ModalModule, CollapseModule, AlertModule, ButtonsModule]
})
export class BootstrapModule { }
