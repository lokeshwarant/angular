import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from './services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class RouteCheckGuard implements CanActivate {
  constructor(private authSvc: AuthenticationService, private Routing: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    
    const token = this.authSvc.getBearerToken();

    if(token == null || token == '' )
    {
      this.Routing.navigate(['login']);
      return false;
    }
    else
    {
      return true;
    }
  }  
}
