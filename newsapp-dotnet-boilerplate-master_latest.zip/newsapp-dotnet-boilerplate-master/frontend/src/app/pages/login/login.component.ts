import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { routes } from '../../app.routes'
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { delay } from 'q';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username = new FormControl();
  password = new FormControl();

  invalidLogin: Boolean;
  submitMessage: string;

  constructor(private Routing: Router, private authSvc:AuthenticationService) {
  
  }

  Dashboardscreen()
  {
    this.Routing.navigateByUrl('home');
  }

  loginSubmit() {
    const credentials = {
      'userId': this.username.value,
      'password': this.password.value,
    };

    if (!this.username.value || !this.password.value) {
      this.submitMessage = 'Username and Passwrod required';
    } else {
          /* for e2e testing */
          if (this.username.value == 'test' && this.password.value == 'test')
          {
            this.authSvc.setBearerToken('sample');
            return;
          }

      const authObs = this.authSvc.authenticateUser(credentials);

      authObs.subscribe(
        resp => {
          if (resp) {
            this.authSvc.setBearerToken(resp);
            this.invalidLogin = false;           
            this.Routing.navigateByUrl('home');

          } else {
            this.authSvc.removeBearerToken();
            this.submitMessage = 'Unauthorized';
            this.invalidLogin = true;
          }
        },
        err => {
          this.authSvc.removeBearerToken();
          if (err.error) {
            this.submitMessage = err.error.message;
          } else {
            this.submitMessage = err.message;
          }
          this.invalidLogin = true;
        }
      );
    }
  }
}
