import { async, ComponentFixture, TestBed, fakeAsync, tick, inject} from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { routing } from '../../app.routes';
import { RouterTestingModule } from '@angular/router/testing';

//import { Observable, throw } from 'rxjs';
import { Observable, throwError, observable, of } from 'rxjs';


import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule, FormControl  } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';

import { AuthenticationService } from 'src/app/services/authentication.service';
import { By } from '@angular/platform-browser';

import { RegistrationComponent } from '../registration/registration.component';
import { FavouriteComponent } from '../favourite/favourite.component';
import { HeadlinesComponent } from '../headlines/headlines.component';
import { CatergoryComponent } from '../catergory/catergory.component';
import { SearchnewsComponent } from '../searchnews/searchnews.component';
import { NewscardComponent } from '../newscard/newscard.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { PagesComponent } from '../pages.component';
import { MatSidenav, MatSidenavModule } from '@angular/material';

const testConfig = {
  error404: {
    message: 'Http failure response for http://localhost:29460/auth/login: 404 Not Found',
    name: 'HttpErrorResponse',
    ok: false,
    status : 404,
    statusText: 'Not Found',
    url: 'http://localhost:29460/auth/login'
  }
};

describe('LoginComponent', () => {
  let fixture: ComponentFixture<LoginComponent>;
  let spyAuthenticateUser: any;
  let spySetBearerToken: any;
  let errorMessage: any;
  let location: Location;
  let element:any;
  let debugElement: any;
  let logComponent:LoginComponent;
  let service: AuthenticationService;
  let spyRouteToDashboard:any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent,
        DashboardComponent,
        FavouriteComponent,
        HeadlinesComponent,
        CatergoryComponent,
        RegistrationComponent,
        SearchnewsComponent,
        NewscardComponent,
        PageNotFoundComponent,
        PagesComponent ]
      ,imports: [
        ReactiveFormsModule ,
        RouterModule,
        FormsModule,
        HttpClientModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatInputModule,
        MatSidenavModule,
        FlexLayoutModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatCardModule,
        MatIconModule,
        MatToolbarModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatFormFieldModule,
        MatInputModule,
      // MatFormFieldModule,
        MatToolbarModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        //MatCardModule,
        MatListModule,
        MatButtonModule,
        MatDialogModule,
        MatSelectModule,
        FormsModule,
        BrowserModule,
        routing
        ],
        providers:
        [AuthenticationService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    logComponent = fixture.componentInstance;
    service = fixture.debugElement.injector.get(AuthenticationService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(logComponent).toBeTruthy();
  });

  it('should handle to login into the system', fakeAsync(() => {
    const token = 'token123';
    spyAuthenticateUser = spyOn(service, 'authenticateUser').and.returnValue(of(token));    
    spySetBearerToken = spyOn(service, 'setBearerToken').and.callFake(function(){
      localStorage.setItem('bearerToken', token);
    });

   // spyRouteToDashboard = spyOn(routing, 'navigateByUrl').and.callFake(function(){});
    const username = new FormControl('deva');
    logComponent.username = username;
    const password = new FormControl('123');
    logComponent.password = password;
    logComponent.loginSubmit(); 

    expect(localStorage.getItem('bearerToken')).toBe(token, 'should get token from local storage');
  }));

  it('should handle empty login', fakeAsync(() => {
    errorMessage = 'Username and Passwrod required';
    spyAuthenticateUser = spyOn(service, 'authenticateUser').and.returnValue(errorMessage);

    const username = new FormControl('');
    logComponent.username = username;
    const password = new FormControl('123');
    logComponent.password = password;
    logComponent.loginSubmit();

    tick();
    fixture.detectChanges();   
    element = fixture.debugElement.query(By.css('.error-message')).nativeElement;
    expect(element.textContent).toContain(errorMessage,`should throw Username and Passwrod required`);
   }));

   it('should handle 404 not found for login', fakeAsync(() => {
    errorMessage = 'Username and Passwrod required';
    spyAuthenticateUser = spyOn(service, 'authenticateUser').and.returnValue(throwError(testConfig.error404));

    const username = new FormControl('123');
    logComponent.username = username;
    const password = new FormControl('123');
    logComponent.password = password;
    logComponent.loginSubmit();
    
    tick();
    fixture.detectChanges();   
    element = fixture.debugElement.query(By.css('.error-message')).nativeElement;
    expect(element.textContent).toContain(testConfig.error404.message,`should store 'err.message' in a varibale 
    'submitMessage' to show error on login page`);
   }));

});
