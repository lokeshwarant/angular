import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';

import { SearchnewsComponent } from './searchnews.component';
import { NewsService } from 'src/app/services/news.service';
import { of, Observable, from } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { FormControl } from '@angular/forms';

const testConfig = {
  getNews: {
    news: [{
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    },
    {
      title: 'two',
      content: 'news 2',
      urlToImage: 'not-started'
    }]
  }
};

describe('SearchnewsComponent', () => {
  let component: SearchnewsComponent;
  let fixture: ComponentFixture<SearchnewsComponent>;
  let service:NewsService;
  let spyGetNews: any;
  let objvalue: Array<any>;
  let debugElement: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchnewsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      imports: [ HttpClientModule, RouterTestingModule ],
      providers : [ NewsService,
                    { provide: ActivatedRoute,
                      useValue: {
                            params: of({searchtext: 'hello'})
                              }
                    }
                  ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    service = TestBed.get(NewsService);
    spyGetNews = spyOn(service, 'GetNewsBytext').and.returnValue(of(testConfig.getNews.news));
  });

  it('should create', () => {
    fixture = TestBed.createComponent(SearchnewsComponent);
    component = fixture.componentInstance;    
    fixture.detectChanges();
  });

   it('should handle get all searched news once component initialized', fakeAsync(() => {
    objvalue = testConfig.getNews.news;
    fixture = TestBed.createComponent(SearchnewsComponent);
    component = fixture.componentInstance;  
    expect(component.searchnews).toBe(objvalue, `should get all news from back end fro teh search text`);
  }));
});
