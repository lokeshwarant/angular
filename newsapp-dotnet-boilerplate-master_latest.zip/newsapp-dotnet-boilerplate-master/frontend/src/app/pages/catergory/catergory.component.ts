import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../services/news.service';

@Component({
  selector: 'app-catergory',
  templateUrl: './catergory.component.html',
  styleUrls: ['./catergory.component.css']
})
export class CatergoryComponent implements OnInit {

  public modeselect = "General"; ; 

  categories = [{value : "Business"},
  {value : "Entertainment"},
  {value : "General"},
  {value : "Health"},
  {value : "Science"},
  {value : "Sports"}];

  categorynews:any = [];
  isCollapsed = true;

  constructor(public service:NewsService){
    
  }

  ngOnInit() {    
      this.getcategorynews("general");
  }

  getcategorynews(text:string) {
    this.categorynews = [];
    this.service.categorynews(text).subscribe((data: {}) => {
      this.categorynews = data;
    });
  }
}
