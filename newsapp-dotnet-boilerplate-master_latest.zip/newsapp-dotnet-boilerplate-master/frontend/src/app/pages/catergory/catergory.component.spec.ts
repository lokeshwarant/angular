import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';

import { CatergoryComponent } from './catergory.component';
import { of } from 'rxjs';
import { NewsService } from 'src/app/services/news.service';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

const testConfig = {
  getNews: {
    news: [{
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    },
    {
      title: 'two',
      content: 'news 2',
      urlToImage: 'not-started'
    }]
  }
};

describe('CatergoryComponent', () => {
  let component: CatergoryComponent;
  let fixture: ComponentFixture<CatergoryComponent>;
  let service: NewsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CatergoryComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [HttpClientModule],
      providers: [NewsService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CatergoryComponent);
    component = fixture.componentInstance;
    service = fixture.debugElement.injector.get(NewsService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get news by category', fakeAsync(() => {
    let objvalue = testConfig.getNews.news;
    let spyGetNews = spyOn(service, 'categorynews').and.returnValue(of(objvalue));
    component.getcategorynews('health');
    expect(component.categorynews).toBe(objvalue, `should get all news from back end by category`);
  }));
});
