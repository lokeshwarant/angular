import { Component, OnInit, Input } from '@angular/core';
import { FavouriteService } from 'src/app/services/favourite.service';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent {

  favouritenews: any = [];
  index: string;
  color = "primary";
  @Input() head: any;

  constructor(public service: FavouriteService) {
    this.getfavouritenews();
  }

  Addtofavourite() {
    this.color = "accent";
  }

  getfavouritenews() {
    this.favouritenews = [];
    this.service.getfavouritenews().subscribe((data: {}) => {
      this.favouritenews = data;
    });
  }

}
