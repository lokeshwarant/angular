import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { RegistrationComponent } from './registration.component';
import { HttpClientModule } from '@angular/common/http';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { of } from 'rxjs';
import { bypassSanitizationTrustStyle } from '@angular/core/src/sanitization/bypass';
import { FormControl } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { Router } from '@angular/router';

describe('RegistrationComponent', () => {
  let component: RegistrationComponent;
  let fixture: ComponentFixture<RegistrationComponent>;
  let service: AuthenticationService;
  let spyLoginUser: any;
  let spySetBearerToken: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationComponent ],
      schemas: [ NO_ERRORS_SCHEMA ],
      imports:[HttpClientModule],
      providers :[{provide: Router, useValue: '/register'}, AuthenticationService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationComponent);
    component = fixture.componentInstance;
     service = fixture.debugElement.injector.get(AuthenticationService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle to any empty value in form input fields', fakeAsync(() => {
    let errorMessage = 'please enter values for all required fields';
    spyLoginUser = spyOn(service, 'registeruser').and.returnValue(errorMessage);

   // spyRouteToDashboard = spyOn(routing, 'navigateByUrl').and.callFake(function(){});
    const firstname = new FormControl('deva');
    component.firstname = firstname;
    const lastname = new FormControl('raj');
    component.password = lastname;
    const username = new FormControl(' ');
    component.username = username;
    const password = new FormControl(' ');
    component.password = password;
    component.register(); 

    tick();
    fixture.detectChanges();   
    let element = fixture.debugElement.query(By.css('.error-message')).nativeElement;
    expect(element.textContent).toContain(errorMessage,`should throw required fields error message`);
  }));
});
