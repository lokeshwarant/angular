import { Component, OnInit, Input } from '@angular/core';
import { FavouriteService } from '../../services/favourite.service'
import { timepickerReducer } from 'ngx-bootstrap/timepicker/reducer/timepicker.reducer';

@Component({
  selector: 'app-newscard',
  templateUrl: './newscard.component.html',
  styleUrls: ['./newscard.component.css']
})
export class NewscardComponent implements OnInit {

  @Input() head: any;
  @Input() index: string;

  color = "primary";
  icon = "favorite";

  constructor(private service: FavouriteService) { }

  ngOnInit() {
  }

  Addtofavourite() {
    const objvalue = {
      //'id': this.index,
      'id': this.head.title,
      'title': this.head.title,
      'content': this.head.content,
      'urlToImage': this.head.urlToImage
    };

    if (this.head.bFavourite == true) {

      const authObs = this.service.deletefavouritenews(encodeURIComponent(this.head.title));

      authObs.subscribe(
        resp => {
          if (resp) {
            this.head.bFavourite = false;
          } else {
            //this.errMessage = 'Un-Successfull';
          }
        },
        err => {
          if (err.error) {
            //this.errMessage = err.error.message;
          } else {
            //this.errMessage = err.message;
          }
        }
      );
    } else {
      const authObs = this.service.createfavouritenews(objvalue);

      authObs.subscribe(
        resp => {
          if (resp) {
            this.head.bFavourite = true;
          } else {
          }
        },
        err => {
          if (err.error) {
            //this.errMessage = err.error.message;
          } else {
            //this.errMessage = err.message;
          }
        }
      );
    }
  }
}
