import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { NewscardComponent } from './newscard.component';
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FavouriteService } from 'src/app/services/favourite.service';
import { HttpClientModule } from '@angular/common/http';
import { throwError } from 'rxjs';

const testConfig = {
  getNews: {
    news: {
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    }
  },
  error404: {
    message: 'Http failure response for http://localhost:55375/news/create: 404 Not Found',
    name: 'HttpErrorResponse',
    ok: false,
    status: 404,
    statusText: 'Not Found',
    url: 'http://localhost:55375/news/create'
  }
};

describe('NewscardComponent', () => {
  let component: NewscardComponent;
  let fixture: ComponentFixture<NewscardComponent>;
  let debugElement: any;
  let element: any;
  let service: FavouriteService;
  let spyCreatefavNews: any;
  let newsComp: NewscardComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NewscardComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [HttpClientModule],
      providers: [FavouriteService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewscardComponent);
    component = fixture.componentInstance;
    service = fixture.debugElement.injector.get(FavouriteService);
    component.head = testConfig.getNews.news;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle to display notes on view', () => {
    debugElement = fixture.debugElement.query(By.css('.card-title'));
    if (debugElement) {
      element = debugElement.nativeElement;
      expect(element.textContent).toContain(testConfig.getNews.news.title,
        `should display 'title' property of news into the <mat-card-title>`);
    } else {
      expect(false).toBe(true,
        `should have an element <mat-card-title> in your component.html to display note 'title'`);
    }
  });

  it('should handle click event of card and toggle the icon', fakeAsync(() => {
    debugElement = fixture.debugElement.query(By.css('.matIcon'));
    spyCreatefavNews = spyOn(service, 'createfavouritenews').and.callFake(function () { });

    if (debugElement) {
      element = debugElement.nativeElement;
      element.click();
      tick();
      expect(component.color).toBe('primary',
        `should change the favourite icon and color')`);
      expect(component.icon).toBe('favorite',
        `should change the favourite icon and color')`);
    } else {
      expect(false).toBe(true,
        `should have an element <mat-icon> in your component.html`);
    }
  }));
});
