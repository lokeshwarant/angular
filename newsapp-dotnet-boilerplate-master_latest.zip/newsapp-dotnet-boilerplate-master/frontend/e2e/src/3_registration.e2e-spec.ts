import { RegistrationPage } from './Pages/registration.po';
import { browser, by, element, ElementFinder, promise } from 'protractor';

describe('Registration page', () => {
  let page: RegistrationPage;

  beforeEach(() => {
    page = new RegistrationPage();
    browser.get('/register'); 
  });

  it('default values of controls should be empty', () => {
    const emptyRegistationValues = ['', '','',''];
    expect(page.getregInputBoxesDefaultValues()).toEqual(emptyRegistationValues, 'Default values for controls should be empty');
  });

  it('new user registration', function() {     
    page.getfirstNametext().sendKeys('nithinkumar');   
    page.getlastNametext().sendKeys('123456');   
    page.getuserNametext().sendKeys('nithin');   
    page.getpasswordtext().sendKeys('123456');   
    page.getregBtn().click();
    browser.get('/login');

    expect(browser.driver.getCurrentUrl()).toContain('/login','User saved successfully and returned to login page');    
  });

});