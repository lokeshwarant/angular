import { browser, by, element, ElementFinder, promise } from 'protractor';

export class RegistrationPage { 
    getfirstNametext(): ElementFinder {
        return element(by.className('firstname'));
      }
      getlastNametext(): ElementFinder {
        return element(by.className('lastname'));
      }
      getuserNametext(): ElementFinder {
        return element(by.className('username'));
      }
      getpasswordtext(): ElementFinder {
        return element(by.className('password'));       
      }

      getregBtn(): ElementFinder {
        return element(by.buttonText('REGISTER'));
      }

    getregInputBoxesDefaultValues():any
    {        
        let firstname, lastname, username, password;
        firstname = this.getfirstNametext().getAttribute('value');
        lastname =  this.getlastNametext().getAttribute('value');
        username = this.getuserNametext().getAttribute('value');
        password = this.getpasswordtext().getAttribute('value');
        
        return Promise.all([ firstname, lastname, username, password]).then( (values) => {
            return values;
          });
    }
}