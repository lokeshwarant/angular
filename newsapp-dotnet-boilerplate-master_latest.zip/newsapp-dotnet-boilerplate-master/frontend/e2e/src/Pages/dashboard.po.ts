import { browser, by, element, ElementFinder, promise } from 'protractor';

export class DashboardPage {
  searchtext = element(by.id('txtsearch'));
  searchBtn = element(by.id('search'));
  favouriteBtn = element(by.id('favourite'));

  getsearchtext(): ElementFinder {
    return element(by.id('txtsearch'));
  }

  getsearchBtn(): ElementFinder {
    return element(by.id('search'));
  }

  getfavouriteBtn(): ElementFinder {
    return element(by.id('favourite'));
  }


  HeadlinesPanel(): ElementFinder {
    return element(by.css('app-headlines'));
  }
  
  Categorypanel(): ElementFinder {
    return element(by.css('app-catergory'));
  }

  isHeadlinesPanelPresent(): promise.Promise<boolean> {
    return this.HeadlinesPanel().isPresent();
  }

  isCategorypanelPresent(): promise.Promise<boolean> {
    return this.Categorypanel().isPresent();
  }
}