
import { FavouritePage } from './Pages/Favourite.po';
import { browser, by, element, ElementFinder, promise } from 'protractor';

describe('Favourite page', () => {
  let page: FavouritePage;

  beforeEach(() => {
    page = new FavouritePage();
  });

  it('should change color on clicking a news', () => {
    browser.get('/home/favourite'); 
   // browser.pause(6000);
    //page.clickLastNews();    
  });
});
