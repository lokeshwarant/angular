﻿using FavouriteService;
using FavouriteService.Controllers;
using FavouriteService.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace FavouriteTest
{
    public class FavControllertest
    {
        [Fact]
        public void CreateFavouriteShouldReturnTrue()
        {
            var mockService = new Mock<IFavouriteService>();
            FavouriteModel objvalue = new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" };


            mockService.Setup(service => service.CreateFavourite(objvalue)).Returns(true);
            var controller = new FavouriteController(mockService.Object);

            var actual = controller.CreateFavourite(objvalue);

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.Equal(true, actionReult.Value);
        }

        [Fact]
        public void DeleteFavouriteShouldReturnTrue()
        {
            var mockService = new Mock<IFavouriteService>();
            FavouriteModel objvalue = new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" };


            mockService.Setup(service => service.Deletefavourite("123")).Returns(true);
            var controller = new FavouriteController(mockService.Object);

            var actual = controller.Deletefavourite("123");

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.Equal(true, actionReult.Value);
        }

        [Fact]
        public void GetFavouriteShouldReturnList()
        {
            var mockService = new Mock<IFavouriteService>();
            mockService.Setup(service => service.GetFavourites()).Returns(this.GetFavourites());
            var controller = new FavouriteController(mockService.Object);

            var actual = controller.GetFavourites();

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.IsAssignableFrom<List<FavouriteModel>>(actionReult.Value);
        }

        private List<FavouriteModel> GetFavourites()
        {
            List<FavouriteModel> Favourites = new List<FavouriteModel>{new FavouriteModel { id = "123", title = "sample", content = "sample news", urlToImage = "test" } };

            return Favourites;
        }
    }
}
