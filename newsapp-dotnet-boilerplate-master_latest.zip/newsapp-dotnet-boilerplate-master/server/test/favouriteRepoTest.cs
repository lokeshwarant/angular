﻿using System;
using System.Collections.Generic;
using server.Models;
using System.Text;
using Xunit;
using server.Exceptions;

namespace test
{
    public class favouriteRepoTest: IClassFixture<DatabaseFixture>
    {
        private readonly server.IFavouriteRepository repo;

        public favouriteRepoTest(DatabaseFixture _fixture)
        {
            repo = new server.FavouriteRepository(_fixture.context);
        }

        [Fact]
        public void CreateFavouriteShouldReturnTrue()
        {
            FavouriteModel objvalue = new FavouriteModel { id = "Nishant", title = "Nishant", content = "admin123", urlToImage = "9892134560" };

            var actual = repo.CreateFavourite(objvalue);

            Assert.True(actual);
        }

        [Fact]
        public void DeleteFavouriteShouldReturnTrue()
        {
            string Id = "123";
            var actual = repo.Deletefavourite(Id);

            Assert.True(actual);
        }

        [Fact]
        public void GetFavouritesShouldReturnlist()
        {
            var actual = repo.GetFavourites();

            Assert.IsAssignableFrom<List<FavouriteModel>>(actual);
        }

        [Fact]
        public void DeleteFavouriteShouldThrowException()
        {
            var actual = Assert.Throws<NotFoundException>(() => repo.Deletefavourite("174"));

            Assert.Equal("No records found", actual.Message);
        }

        [Fact]
        public void AllNewsAsync()
        {
            var actual = repo.AllNewsAsync();

            Assert.IsAssignableFrom<Resultmodel>(actual);
        }

        [Fact]
        public void GetNewsByCategory()
        {
            var actual = repo.GetNewsByCategory("general");

            Assert.IsAssignableFrom<Resultmodel>(actual);
        }

        [Fact]
        public void GetNewsBytext()
        {
            var actual = repo.GetNewsBytext("test");

            Assert.IsAssignableFrom<Resultmodel>(actual);
        }       
    }
}
