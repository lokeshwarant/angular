﻿using server.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    public class DatabaseFixture:IDisposable
    {
        public IFavouriteContext context;

        public DatabaseFixture()
        {
            var options = new DbContextOptionsBuilder<FavouriteContext>()
                .UseInMemoryDatabase(databaseName: "NewsDb")
                .Options;

            //Initializing DbContext with InMemory
            context = new FavouriteContext(options);

            // Insert seed data into the database using one instance of the context
            context.Favourites.Add(new FavouriteModel { id = "123", title = "sample", content = "sample news", urlToImage = "test"});
            context.SaveChanges();
        }
        public void Dispose()
        {
            context = null;
        }
    }
}
