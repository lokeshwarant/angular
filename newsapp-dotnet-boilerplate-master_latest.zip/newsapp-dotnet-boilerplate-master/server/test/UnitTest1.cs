using System;
using Xunit;
using server;
using server.Models;
using System.Collections.Generic;
using server.Exceptions;
using Moq;

namespace test
{
    public class UnitTest1
    {
         [Fact]
         public void CreateFavouriteShouldReturnTrue()
         {
            var mockrepo = new Mock<IFavouriteRepository>();
            FavouriteModel objvalue = new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" };


            mockrepo.Setup(repo => repo.CreateFavourite(objvalue)).Returns(true);
            var service = new NewsService(mockrepo.Object);

            var actual = service.CreateFavourite(objvalue);            
            Assert.True(actual);
        }

        [Fact]
        public void GetFavouritesShouldReturnModel()
        {
            var mockrepo = new Mock<IFavouriteRepository>();
            List<FavouriteModel> objvalue =new List<FavouriteModel>{ new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" } };


            mockrepo.Setup(repo => repo.GetFavourites()).Returns(objvalue);
            var service = new NewsService(mockrepo.Object);

            var actual = service.GetFavourites();
            Assert.Equal(objvalue, actual );
        }

        [Fact]
        public void GetNewsBytextShouldThrowException()
        {
            var mockrepo = new Mock<IFavouriteRepository>();
            Resultmodel objvalue = new Resultmodel();

            mockrepo.Setup(repo => repo.GetNewsBytext("0000")).Returns(objvalue);
            var service = new NewsService(mockrepo.Object);

            var actual = Assert.Throws<NotFoundException>(() => service.GetNewsBytext("0000"));
            Assert.Equal("No Results found", actual.Message);
        }

        [Fact]
        public void GetNewsByCategoryShouldThrowException()
        {
            var mockRepo = new Mock<IFavouriteRepository>();
            mockRepo.Setup(repo => repo.GetNewsByCategory("null")).Returns(new Resultmodel());
            var service = new NewsService(mockRepo.Object);         

            var actual = Assert.Throws<NotFoundException>(() => service.GetNewsByCategory("null"));

            Assert.Equal("No Results found", actual.Message);
        }
    }
}
