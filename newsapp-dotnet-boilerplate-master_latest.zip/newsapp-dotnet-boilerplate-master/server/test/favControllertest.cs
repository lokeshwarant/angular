﻿using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using server;
using Xunit;
using server.Models;
using Microsoft.AspNetCore.Mvc;

namespace test
{
    public class favControllertest
    {
        [Fact]
        public void CreateFavouriteShouldReturnTrue()
        {
            var mockService = new Mock<INewsService>();
            FavouriteModel objvalue = new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" };


            mockService.Setup(service => service.CreateFavourite(objvalue)).Returns(true);
            var controller = new NewsController(mockService.Object);

            var actual = controller.CreateFavourite(objvalue);

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.Equal(true, actionReult.Value);
        }

        [Fact]
        public void DeleteFavouriteShouldReturnTrue()
        {
            var mockService = new Mock<INewsService>();
            FavouriteModel objvalue = new FavouriteModel { id = "124", title = "sample", content = "sample news", urlToImage = "test" };


            mockService.Setup(service => service.Deletefavourite("123")).Returns(true);
            var controller = new NewsController(mockService.Object);

            var actual = controller.Deletefavourite("123");

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.Equal(true, actionReult.Value);
        }

        [Fact]
        public void GetFavouriteShouldReturnList()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.GetFavourites()).Returns(this.GetFavourites());
            var controller = new NewsController(mockService.Object);

            var actual = controller.GetFavourites();

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.IsAssignableFrom<List<FavouriteModel>>(actionReult.Value);
        }

        [Fact]
        public void GetNewsByCategoryShouldReturnNews()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.AllNewsAsync()).Returns(this.GetNews());
            var controller = new NewsController(mockService.Object);

            var actual = controller.AllNews();

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.IsAssignableFrom<List<NewsModel>>(actionReult.Value);
        }

        [Fact]
        public void GetNewsShouldReturnNewsModel()
        {
            var mockService = new Mock<INewsService>();
            mockService.Setup(service => service.GetNewsByCategory("health")).Returns(this.GetNews());
            var controller = new NewsController(mockService.Object);

            var actual = controller.newsbycategory("health");

            var actionReult = Assert.IsType<OkObjectResult>(actual);
            Assert.IsAssignableFrom<List<NewsModel>>(actionReult.Value);
        }

        private List<FavouriteModel> GetFavourites()
        {
            List<FavouriteModel> Favourites = new List<FavouriteModel> { new FavouriteModel { id = "123", title = "sample", content = "sample news", urlToImage = "test" } };

            return Favourites;
        }

        private List<NewsModel> GetNews()
        {
            List<NewsModel> News = new List<NewsModel> { new NewsModel { author = "CNB", title = "sample", content = "sample news", urlToImage = "Image to url" } };

            return News;
        }
    }
}
