﻿using Microsoft.EntityFrameworkCore;

namespace FavouriteService.Models
{
    public interface IFavouriteContext
    {
        DbSet<FavouriteModel> Favourites { get; set; }
        int SaveChanges();
    }
}