﻿using System.Collections.Generic;
using FavouriteService.Models;

namespace FavouriteService
{
    public interface IFavouriteService
    {
        bool CreateFavourite(FavouriteModel news);
        bool Deletefavourite(string Id);
        List<FavouriteModel> GetFavourites();
    }
}