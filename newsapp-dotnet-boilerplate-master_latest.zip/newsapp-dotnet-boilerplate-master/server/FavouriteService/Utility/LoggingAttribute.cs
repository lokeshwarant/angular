﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavouriteService.Utility
{
    public class LoggingAttribute: ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var type = context.Exception.GetType();
            var msg = context.Exception.Message;

            if (type == typeof(NotFoundException))
            {
                var value = new NotFoundObjectResult(msg);
                context.Result = value;
            }
            else
            {
                var result = new StatusCodeResult(500);
                context.Result = result;
            }
        }
    }
}
