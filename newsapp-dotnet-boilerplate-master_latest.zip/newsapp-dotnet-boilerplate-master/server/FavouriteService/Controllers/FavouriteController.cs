﻿using FavouriteService.Models;
using FavouriteService.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavouriteService.Controllers
{
    [Route("favourite")]
    [Authorize]
    [Logging]
    public class FavouriteController : Controller
    {
        private readonly IFavouriteService Service;

        public FavouriteController(IFavouriteService objvalue)
        {
            this.Service = objvalue;
        }

        [HttpPost]
        [Route("create")]
        public IActionResult CreateFavourite([FromBody]FavouriteModel objvalue)
        {
            return Ok(Service.CreateFavourite(objvalue));
        }

        [HttpGet]
        [Route("get")]
        public IActionResult GetFavourites()
        {
            return Ok(Service.GetFavourites()); ;
        }

        [HttpDelete]
        [Route("delete/{Id}")]
        public IActionResult Deletefavourite(string Id)
        {
            return Ok(Service.Deletefavourite(Id));
        }
    }
}
