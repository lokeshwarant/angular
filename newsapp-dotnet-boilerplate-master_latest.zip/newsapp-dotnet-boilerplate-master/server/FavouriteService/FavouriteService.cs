﻿using FavouriteService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavouriteService
{
    public class FavouriteService : IFavouriteService
    {
        private readonly IFavouriteContext context;

        public FavouriteService(IFavouriteContext objvalue)
        {
            this.context = objvalue;
        }

        public bool CreateFavourite(FavouriteModel news)
        {
            var result = context.Favourites.FirstOrDefault(u => u.id == news.id);

            if (result == null)
            {
                context.Favourites.Add(news);
                context.SaveChanges();

                return true;
            }
            else
                return false;
        }

        public List<FavouriteModel> GetFavourites()
        {
            return context.Favourites.ToList();
        }

        public bool Deletefavourite(string Id)
        {
            var result = context.Favourites.FirstOrDefault(c => c.id == Id);

            if (result != null)
            {
                var value = context.Favourites.Remove(result);
                context.SaveChanges();

                return true;
            }
            else
                throw new NotFoundException("No records found");
        }

    }
}
