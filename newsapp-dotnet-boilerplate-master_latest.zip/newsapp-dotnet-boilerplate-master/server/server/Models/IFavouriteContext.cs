﻿using Microsoft.EntityFrameworkCore;

namespace server.Models
{
    public interface IFavouriteContext
    {
        DbSet<FavouriteModel> Favourites { get; set; }
        int SaveChanges();
    }
}