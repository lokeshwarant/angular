﻿using System.Collections.Generic;
using server.Models;

namespace server
{
    public interface INewsService
    {
        List<NewsModel> AllNewsAsync();
        bool CreateFavourite(FavouriteModel news);
        bool Deletefavourite(string Id);
        List<FavouriteModel> GetFavourites();
        List<NewsModel> GetNewsByCategory(string value);
        List<NewsModel> GetNewsBytext(string value);
        List<NewsModel> UpdateFavouriteList(List<NewsModel> objValue);
    }
}