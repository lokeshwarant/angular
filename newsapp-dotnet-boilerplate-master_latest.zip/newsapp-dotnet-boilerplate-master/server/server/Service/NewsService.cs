﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using server.Exceptions;
using server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace server
{
    public class NewsService : INewsService
    {
        private readonly IFavouriteRepository repo;

        public NewsService(IFavouriteRepository objvalue)
        {
            this.repo = objvalue;
        }

        public List<NewsModel> AllNewsAsync()
        {
            Resultmodel objResult = new Resultmodel();

            objResult = this.repo.AllNewsAsync();

            if (objResult.totalResults > 0 && objResult.status == "ok")
                return UpdateFavouriteList(objResult.articles);
           else
                throw new NotFoundException("No Results found");
        }

        public List<NewsModel> GetNewsByCategory(String value)
        {
            Resultmodel objResult = new Resultmodel();
            objResult = this.repo.GetNewsByCategory(value);

            if (objResult.totalResults > 0 && objResult.status == "ok")
                return UpdateFavouriteList(objResult.articles);
            else
                throw new NotFoundException("No Results found");
        }

        public List<NewsModel> GetNewsBytext(String value)
        {
            Resultmodel objResult = new Resultmodel();
            objResult = this.repo.GetNewsBytext(value);

            if (objResult.totalResults > 0 && objResult.status == "ok")
                return UpdateFavouriteList(objResult.articles);
            else
                throw new NotFoundException("No Results found");
        }

        public List<NewsModel> UpdateFavouriteList(List<NewsModel> objValue)
        {
            List<FavouriteModel> objFav = repo.GetFavourites();

            if(objValue.Count > 0 && objValue != null)
            {
                objFav.ForEach(f =>
                {
                    if(objValue.Any(i => i.title == f.title ))
                        objValue.Find(e => e.title == f.title).bFavourite = true;
                });
            }

            return objValue;
        }

        public bool CreateFavourite(FavouriteModel news)
        {
            return repo.CreateFavourite(news);
        }

        public List<FavouriteModel> GetFavourites()
        {
            return repo.GetFavourites();
        }

        public bool Deletefavourite(string Id)
        {
            return repo.Deletefavourite(Id);
        }
    }
}
