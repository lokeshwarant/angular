﻿using System.Collections.Generic;
using server.Models;

namespace server
{
    public interface IFavouriteRepository
    {
        Resultmodel AllNewsAsync();
        bool CreateFavourite(FavouriteModel news);
        bool Deletefavourite(string Id);
        List<FavouriteModel> GetFavourites();
        Resultmodel GetNewsByCategory(string value);
        Resultmodel GetNewsBytext(string value);
    }
}