﻿using server.Exceptions;
using server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;

namespace server
{
    public class FavouriteRepository : IFavouriteRepository
    {
        private readonly IFavouriteContext context;

        public FavouriteRepository(IFavouriteContext objvalue)
        {
            this.context = objvalue;
        }

        public Resultmodel AllNewsAsync()
        {
            Resultmodel objResult = new Resultmodel();
            string path = "https://newsapi.org/v2/top-headlines?country=us&apiKey=875d9bec52f249f1b30631924f8e0e63";

            using (var HttpClient = new HttpClient())
            {
                //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                var response = HttpClient.GetAsync(new Uri(path)).Result;

                object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);

                return JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());
            }

        }

        public Resultmodel GetNewsByCategory(String value)
        {
            string path = "https://newsapi.org/v2/top-headlines?apikey=875d9bec52f249f1b30631924f8e0e63&page=1&";

            path = path + "category=" + value;

            using (var HttpClient = new HttpClient())
            {
                //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                var response = HttpClient.GetAsync(new Uri(path)).Result;

                object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);
                Resultmodel objResult = new Resultmodel();
                return JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());

            }

        }

        public Resultmodel GetNewsBytext(String value)
        {
            string path = "https://newsapi.org/v2/everything?apikey=875d9bec52f249f1b30631924f8e0e63&page=1&language=en&";

            path = path + "q=" + value;

            using (var HttpClient = new HttpClient())
            {
                //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                var response = HttpClient.GetAsync(new Uri(path)).Result;

                object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);
                Resultmodel objResult = new Resultmodel();
                return JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());
            }

        }

        public bool CreateFavourite(FavouriteModel news)
        {
            var result = context.Favourites.FirstOrDefault(u => u.id == news.id);

            if (result == null)
            {
                context.Favourites.Add(news);
                context.SaveChanges();

                return true;
            }
            else
                return false;
        }

        public List<FavouriteModel> GetFavourites()
        {
            return context.Favourites.ToList();
        }

        public bool Deletefavourite(string Id)
        {
            var result = context.Favourites.FirstOrDefault(c => c.id == Id);

            if (result != null)
            {
                var value = context.Favourites.Remove(result);
                context.SaveChanges();

                return true;
            }
            else
                throw new NotFoundException("No records found");
        }
    }
}
