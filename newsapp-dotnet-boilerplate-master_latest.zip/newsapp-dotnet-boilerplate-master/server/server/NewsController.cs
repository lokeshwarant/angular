﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace server
{
    [Route("news")]
    [Authorize]
    [Logging]
    public class NewsController : Controller
    {
        public readonly INewsService service;

        public NewsController(INewsService objvalue)
        {
            this.service = objvalue;
        }

        [Route("allnews")]
        [HttpGet]
        public IActionResult AllNews()
        {
            return Ok(service.AllNewsAsync());
        }

        [Route("newsbycategory/{text}")]
        [HttpGet]
        public IActionResult newsbycategory(String text)
        {
            return Ok(service.GetNewsByCategory(text));
        }

        [Route("newsbytext/{text}")]
        [HttpGet]
        public IActionResult newsbytext(String text)
        {
            return Ok(service.GetNewsBytext(text));
        }

        [HttpPost]
        [Route("create")]
        public IActionResult CreateFavourite([FromBody]FavouriteModel objvalue)
        {
            return Ok(service.CreateFavourite(objvalue));
        }

        [HttpGet]
        [Route("get")]
        public IActionResult GetFavourites()
        {
            return Ok(service.GetFavourites());
        }

        [HttpDelete]
        [Route("delete/{Id}")]
        public IActionResult Deletefavourite(string Id)
        {
            return Ok(service.Deletefavourite(Id));
        }
    }    
}
