export class Note {
    title: string;
    text: string;
}
