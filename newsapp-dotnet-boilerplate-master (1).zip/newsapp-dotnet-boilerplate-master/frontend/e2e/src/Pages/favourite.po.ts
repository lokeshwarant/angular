import { browser, by, element, ElementFinder, promise, ElementArrayFinder } from 'protractor';

export class FavouritePage {

 getAllNews(): ElementArrayFinder {
    return element.all(by.css('card-picture'));
  }

  getLastNews(): ElementFinder {
    return this.getAllNews().last();
  }

  getLastNewsIcon(): ElementFinder {
    return this.getLastNews().last().element(by.id('icon'));
  }

  clickLastNews(): promise.Promise<void> {
    return this.getLastNewsIcon().click();
  }

}