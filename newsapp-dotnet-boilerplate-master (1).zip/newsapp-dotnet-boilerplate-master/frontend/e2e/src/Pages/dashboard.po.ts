import { browser, by, element, ElementFinder, promise } from 'protractor';

export class DashboardPage {
    searchtext = element(by.id('txtsearch'));
    searchBtn = element(by.id('search'));
    favouriteBtn = element(by.id('favourite'));

    getsearchtext(): ElementFinder {
        return element(by.id('txtsearch'));
      }

      getsearchBtn(): ElementFinder {
        return element(by.id('search'));
      }

      getfavouriteBtn(): ElementFinder {
        return element(by.id('favourite'));
      }

    isHeadlinesPanelPresent(): promise.Promise<boolean> {
        return  element(by.tagName('app-headlines')).isPresent();
      }

    isCategorypanelPresent(): promise.Promise<boolean> {
        return element(by.tagName('app-category')).isPresent();
      }
}