import { browser, by, element, ElementFinder, promise } from 'protractor';

export class LoginPage {

  navigateToLogin() {
    return browser.get('/login');
  }
  
  getCurrentURL() {
    return browser.getCurrentUrl();
  }

  navigateToDashboard() {
    return browser.get('/home/dashboard');
  }

  getloginComponent(): ElementFinder {
    return element(by.tagName('app-login'));
  }

  getUserNameInputBox(): ElementFinder {
    return element(by.className('username'));
  }

  isUserNameInputBoxPresent(): promise.Promise<boolean> {
    return this.getUserNameInputBox().isPresent();
  }
 
  getPasswordInputBox(): ElementFinder {
    return element(by.className('password'));
  }
 
  isPasswordInputBoxPresent(): promise.Promise<boolean> {
    return this.getPasswordInputBox().isPresent();
  }
 
  getSubmitButton(): ElementFinder {
    return this.getloginComponent().element(by.buttonText('Submit'));
  }
 
  isSubmitButtonPresent(): promise.Promise<boolean> {
    return this.getSubmitButton().isPresent();
  }

  clickSubmitButton(): promise.Promise<void> {
    return this.getSubmitButton().click();
  }

  getLoginInputBoxesDefaultValues(): any {
    let inputUsername, inputPassword;
    inputUsername = this.getUserNameInputBox().getAttribute('value');
    inputPassword = this.getPasswordInputBox().getAttribute('value');
    return Promise.all([inputUsername, inputPassword]).then( (values) => {
      return values;
    });
  }

  getMockLoginDetail(): any {
    const loginDetail: any = { username: 'admin', password : 'test'};
    return loginDetail;
  }
  // set username and password input box values
  addLoginValues(): any {
    const login: any = this.getMockLoginDetail();
    this.getUserNameInputBox().sendKeys(login.username);
    this.getPasswordInputBox().sendKeys(login.password);
    return Object.keys(login).map(key => login[key]);
  }
}