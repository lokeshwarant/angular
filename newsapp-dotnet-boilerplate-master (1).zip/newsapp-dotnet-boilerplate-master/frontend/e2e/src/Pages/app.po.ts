import { browser, by, element, ElementFinder, promise } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
   // return browser.get(browser.baseUrl) as Promise<any>;
  }

  getTitleText() {
    return element(by.css('error-message')).getText() as Promise<string>;
  }
}
