import { DashboardPage } from './Pages/dashboard.po';
import { browser, by, element, ElementFinder, promise } from 'protractor';

describe('Dashboard page', () => {
  let page: DashboardPage;

  beforeEach(() => {
    page = new DashboardPage();
    browser.get('/home/dashboard'); 
  });

  it('should render headlines and category panel', () => {     
    expect(page.isHeadlinesPanelPresent).toBeTruthy('<app-headlines> should exist');
    expect(page.isCategorypanelPresent).toBeTruthy('<app-category> should exist');
  });

  it('should open search screen on clicking search', () => {      
    page.getsearchtext().sendKeys('hello');
    page.getsearchBtn().click();
    expect(browser.driver.getCurrentUrl()).toContain('/home/search/hello','naviagted to Search screen with search text');    
  });

  it('should open favourite view by clicking on favourite button', () => {
    browser.get('/home/dashboard');
    page.getfavouriteBtn().click();
    expect(browser.driver.getCurrentUrl()).toContain('/home/favourite','naviagted to favourite view');
  });

  
  
 /* it('should render headlines and category panel', () => {
    browser.get('/home/dashboard');       
    expect(page.headlines.isPresent()).toBeTruthy('<app-headlines> should exist');
    expect(page.category.isPresent()).toBeTruthy('<app-category> should exist');
  });*/

});