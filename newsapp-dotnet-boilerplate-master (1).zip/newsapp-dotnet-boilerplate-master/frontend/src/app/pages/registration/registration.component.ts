import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { delay } from 'q';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent  {

  errMessage: string;

  username = new FormControl();
  password = new FormControl();
  firstname = new FormControl();
  lastname = new FormControl();

  constructor(private service:AuthenticationService,private Routing: Router) { }

  ngOnInit() {   
  }

  register() {
    const objvalue = {
      'userId': this.username.value,
      'password': this.password.value,
      'firstName': this.firstname.value,
      'lastname': this.lastname.value,
    };

    if (!this.username.value || !this.password.value) {
      this.errMessage = 'please enter values for all required fields';
    } 
    else{
        const authObs = this.service.registeruser(objvalue);
  
        authObs.subscribe(
          resp => {
            if (resp) {
              alert('Saved Successfully');
              this.Routing.navigate(['login']);
            } else {
              this.errMessage = 'Un-Successfull';
            }
          },
          err => {
            this.service.removeBearerToken();
            if (err.error) {
              this.errMessage = err.error.message;
            } else {
              this.errMessage = err.message;
            }
          }
        );
      }

    }

}
