import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';

import { FavouriteComponent } from './favourite.component';
import { FavouriteService } from 'src/app/services/favourite.service';

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const testConfig = {
  getNews: {
    news: [{
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    },
    {
      title: 'two',
      content: 'news 2',
      urlToImage: 'not-started'
    }]
  }
};

describe('FavouriteComponent', () => {
  let component: FavouriteComponent;
  let fixture: ComponentFixture<FavouriteComponent>;
  let service: FavouriteService;
  let spyGetfavNews: any;
  let objvalue: Array<any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavouriteComponent ],
      imports: [HttpClientModule],
      schemas: [NO_ERRORS_SCHEMA],
      providers :[ FavouriteService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    service = TestBed.get(FavouriteService);
    spyGetfavNews = spyOn(service, 'getfavouritenews').and.returnValue(of(testConfig.getNews.news));    
  });

  it('should create', () => {
    fixture = TestBed.createComponent(FavouriteComponent);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });

  it('fetchNewsFromServer should be called whenever FavouriteComponent is rendered', () => {
    fixture = TestBed.createComponent(FavouriteComponent);
    component = fixture.componentInstance;
    expect(service.getfavouritenews).toHaveBeenCalled();
  }); 

  it('should handle get all favourite news once component initialized', fakeAsync(() => {
    objvalue = testConfig.getNews.news;
    //spyGetfavNews = spyOn(service, 'getfavouritenews').and.returnValue(of(objvalue));
   // component.getfavouritenews();
    expect(component.favouritenews).toBe(objvalue, `should get all favourite news from back end`);
  }));
  
});
