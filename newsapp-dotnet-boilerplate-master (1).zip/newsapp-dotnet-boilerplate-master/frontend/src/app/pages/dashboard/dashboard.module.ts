import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    //RouterModule.forChild(routes),
    FormsModule
  ],
  declarations: [
    DashboardComponent]
})

export class DashboardModule { }
