import { Component, OnInit } from '@angular/core';
import { NewsService } from '../../services/news.service';

@Component({
  selector: 'app-catergory',
  templateUrl: './catergory.component.html',
  styleUrls: ['./catergory.component.css']
})
export class CatergoryComponent implements OnInit {

  public modeselect = "general"; ; 

  categories = [{value : "business"},
  {value : "entertainment"},
  {value : "general"},
  {value : "health"},
  {value : "science"},
  {value : "sports"}];

  categorynews:any = [];

  constructor(public service:NewsService){}

  ngOnInit() {    
    if(this.categorynews.length == 0)
      this.getcategorynews("general");
  }

  getcategorynews(text:string) {
    this.categorynews = [];
    this.service.categorynews(text).subscribe((data: {}) => {
      this.categorynews = data;
    });
  }
}
