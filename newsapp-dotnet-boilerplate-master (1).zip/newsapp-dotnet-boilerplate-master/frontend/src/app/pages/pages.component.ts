import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {

  txtSearch = new FormControl();

  constructor(private Routing: Router, private authSvc:AuthenticationService) {
    
  }

  ngOnInit() {
  }

  isDashboard = true;

  switchToDashboard() {
    this.isDashboard = true;
    this.Routing.navigate(['home/dashboard']);
    this.txtSearch = new FormControl('');
  }

  switchTofavourite() {
    this.isDashboard = false;
    this.Routing.navigate(['home/favourite']);
  }

  LogOut() {
    this.authSvc.removeBearerToken();
    this.Routing.navigate(['login']);
  }

  searchnews()
  {
      if(this.txtSearch.value != '' && this.txtSearch.value != null )
      {
        this.isDashboard = false;
        this.Routing.navigate(['home/search', this.txtSearch.value]);
      }
    //  this.Routing.navigate([
    //   'home', {
    //      'outlets' : {
    //      newsoutlet : [
    //        'search', 'hello'
    //        ]
    //    }
    //    }
    //  ]);
  }

}
