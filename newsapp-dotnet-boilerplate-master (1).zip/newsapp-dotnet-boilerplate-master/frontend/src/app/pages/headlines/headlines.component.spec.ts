import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';

import { HeadlinesComponent } from './headlines.component';
import { of } from 'rxjs';
import { NewsService } from 'src/app/services/news.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

const testConfig = {
  getNews: {
    news: [{
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    },
    {
      title: 'two',
      content: 'news 2',
      urlToImage: 'not-started'
    }]
  }
};

describe('HeadlinesComponent', () => {
  let component: HeadlinesComponent;
  let fixture: ComponentFixture<HeadlinesComponent>;
  let service: NewsService;
  let spyGetNews: any;
  let objvalue: Array<any>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeadlinesComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      imports: [ HttpClientModule ],
      providers : [ NewsService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeadlinesComponent);
    component = fixture.componentInstance;
    service = fixture.debugElement.injector.get(NewsService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle get all headlines news', fakeAsync(() => {
    objvalue = testConfig.getNews.news;
    spyGetNews = spyOn(service, 'getheadlines').and.returnValue(of(objvalue));
    component.getheadlines();
    expect(component.headlines).toBe(objvalue, `should get all news from back end`);
  }));

});
