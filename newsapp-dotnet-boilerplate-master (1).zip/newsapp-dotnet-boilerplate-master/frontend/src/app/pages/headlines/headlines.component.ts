import { Component, OnInit, Input } from '@angular/core';
import { NewsService } from '../../services/news.service';
import { headersToString } from 'selenium-webdriver/http';

@Component({
  selector: 'app-headlines',
  templateUrl: './headlines.component.html',
  styleUrls: ['./headlines.component.css']
})
export class HeadlinesComponent implements OnInit {

  headlines:any = [];
  index:string;
  color = "primary";
  @Input() head: any;

  constructor(public service:NewsService){}

  ngOnInit() {
    if(this.headlines.length == 0)
      this.getheadlines();
  }

  Addtofavourite()
  {
    this.color = "accent";
  }

  getheadlines() {
    this.headlines = [];
    this.service.getheadlines().subscribe((data: {}) => {
      
      this.headlines = data;
    });
  }
}
