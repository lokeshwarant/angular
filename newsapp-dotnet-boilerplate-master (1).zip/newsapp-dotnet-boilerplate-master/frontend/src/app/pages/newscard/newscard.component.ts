import { Component, OnInit, Input } from '@angular/core';
import { FavouriteService } from '../../services/favourite.service'

@Component({
  selector: 'app-newscard',
  templateUrl: './newscard.component.html',
  styleUrls: ['./newscard.component.css']
})
export class NewscardComponent implements OnInit {

  @Input() head: any;
  @Input() index: string;

  color = "primary";
  icon = "favorite";

  constructor(private service: FavouriteService) { }

  ngOnInit() {
  }

  Addtofavourite() {
    const objvalue = {
      //'id': this.index,
      'id': this.head.title,
      'title': this.head.title,
      'content': this.head.content,
      'urlToImage': this.head.urlToImage
    };

    if (this.color == "accent") {

      const authObs = this.service.deletefavouritenews(encodeURIComponent(this.head.title));

      authObs.subscribe(
        resp => {
          if (resp) {
            this.icon = "favorite";
            this.color = "primary";
          } else {
            //this.errMessage = 'Un-Successfull';
          }
        },
        err => {
          if (err.error) {
            //this.errMessage = err.error.message;
          } else {
            //this.errMessage = err.message;
          }
        }
      );
    } else {
      const authObs = this.service.createfavouritenews(objvalue);

      authObs.subscribe(
        resp => {
          if (resp) {
            this.icon = "favorite_border";
            this.color = "accent";
          } else {
            this.icon = "favorite_border";
            this.color = "accent";
          }
        },
        err => {
          if (err.error) {
            //this.errMessage = err.error.message;
          } else {
            //this.errMessage = err.message;
          }
        }
      );
    }
  }
}
