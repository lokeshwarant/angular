import { Component, OnInit, Inject } from '@angular/core';
import { NewsService } from '../../services/news.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-searchnews',
  templateUrl: './searchnews.component.html',
  styleUrls: ['./searchnews.component.css']
})
export class SearchnewsComponent implements OnInit {
   
  searchnews:any = [];
  text:string;

  constructor(private service: NewsService,
    private route:ActivatedRoute, private router: Router) {
 
      //this.route.snapshot.params.
      this.route.params.subscribe(params => {     
          this.text = params['searchtext'];
   });
    this.searchnews = [];
    this.service.GetNewsBytext(this.text).subscribe((data: {}) => {      
      this.searchnews = data;
    });    
  }


  ngOnInit() {
  }

}
