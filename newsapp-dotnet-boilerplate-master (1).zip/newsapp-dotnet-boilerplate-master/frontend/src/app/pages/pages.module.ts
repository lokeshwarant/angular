import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


//import { routing } from './pages.routing';
import { BootstrapModule } from '../module/bootstrap/bootstrap.module';

import { HeadlinesComponent } from './headlines/headlines.component';
import { PagesComponent } from './pages.component';
import { MatToolbar, MatButtonModule, MatToolbarModule, MatButtonToggle } from '@angular/material';
import { CatergoryComponent } from './catergory/catergory.component';
import { FavouriteComponent } from './favourite/favourite.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchnewsComponent } from './searchnews/searchnews.component';
import { NewscardComponent } from './newscard/newscard.component';


@NgModule({
  imports: [
    CommonModule,
//routing,
    MatButtonModule,
    MatButtonToggle,
    MatToolbarModule,
    BootstrapModule    
  ],
  declarations: [
    PagesComponent,
   // HeaderComponent,   
  // FavouriteComponent,
//DashboardComponent,
   HeadlinesComponent,
   CatergoryComponent,
   SearchnewsComponent,
   NewscardComponent,
   // CatergoryComponent,
  ]
})
export class PagesModule { }
