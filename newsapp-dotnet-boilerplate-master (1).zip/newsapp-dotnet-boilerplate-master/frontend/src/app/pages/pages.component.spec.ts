import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routing } from '../app.routes';
import {APP_BASE_HREF} from '@angular/common';
import { BootstrapModule } from '../module/bootstrap/bootstrap.module';

import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule, FormControl  } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { Location } from '@angular/common';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';


import { LoginComponent } from './login/login.component'
import { RegistrationComponent } from './registration/registration.component';
import { FavouriteComponent } from './favourite/favourite.component';
import { HeadlinesComponent } from './headlines/headlines.component';
import { CatergoryComponent } from './catergory/catergory.component';
import { SearchnewsComponent } from './searchnews/searchnews.component';
import { NewscardComponent } from './newscard/newscard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

import { PagesComponent } from './pages.component';
import { routes} from '../app.routes';
import { FavouriteService } from '../services/favourite.service';
import { of } from 'rxjs';
import { NewsService } from '../services/news.service';

const testConfig = {
  getNews: {
    news: [{
      title: 'one',
      content: 'news 1',
      urlToImage: 'not-started'
    },
    {
      title: 'two',
      content: 'news 2',
      urlToImage: 'not-started'
    }]
  }
};

describe('PagesComponent', () => {
  let component: PagesComponent;
  let fixture: ComponentFixture<PagesComponent>;
  let router: Router;
  let spyGetfavNews: any;
  let spyGetNewsbyText: any;
  let debugElement: any;
  let favcomp : FavouriteComponent;
  let service : FavouriteService;
  let NewsService: NewsService;
  let element: any;
  let location: Location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagesComponent, 
        LoginComponent,
        PagesComponent,
        DashboardComponent,
        FavouriteComponent,
        HeadlinesComponent,
        CatergoryComponent,
        RegistrationComponent,
        SearchnewsComponent,
        NewscardComponent,
        PageNotFoundComponent ],
      imports: [
        RouterTestingModule.withRoutes(routes),
        ReactiveFormsModule ,
        RouterModule,
        FormsModule,
        BootstrapModule,
        HttpClientModule,
        BrowserModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        BrowserAnimationsModule,
        MatInputModule,
        FlexLayoutModule,
        BrowserModule,
        BrowserAnimationsModule,
        MatCardModule,
        MatIconModule,
        MatToolbarModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatFormFieldModule,
        MatInputModule,
      // MatFormFieldModule,
        MatToolbarModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        //MatCardModule,
        MatListModule,
        MatButtonModule,
        MatDialogModule,
        MatSelectModule,
        FormsModule,
        BrowserModule,
        routing
        ],
        schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
        providers: [{provide: APP_BASE_HREF, useValue: '/'}, FavouriteService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagesComponent);
    let fixture1 = TestBed.createComponent(SearchnewsComponent);
    location = TestBed.get(Location);
    component = fixture.componentInstance;
    service = fixture.debugElement.injector.get(FavouriteService);
    fixture.detectChanges();   
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle navigation to Favourite view', fakeAsync(() => {
    debugElement = fixture.debugElement.query(By.css('.favourite'));
    spyGetfavNews = spyOn(service, 'getfavouritenews').and.returnValue(of(testConfig.getNews.news));

    if (debugElement) {
      element = debugElement.nativeElement;
      element.click();      
      tick();
      expect(location.path()).toContain('/home/favourite',
        `should navigate to Favourite view page`);
    } else {
      expect(false).toBe(true,
        `should have an element with class 'favourite' in your pages.html`);
    }
  }));

  it('should handle navigation to Dashboard view', fakeAsync(() => {
    component.isDashboard = false;
    fixture.detectChanges();
    
    debugElement = fixture.debugElement.query(By.css('.dashboard'));
    if (debugElement) {
      element = debugElement.nativeElement;
      element.click();      
      tick();
      expect(location.path()).toContain('/home/dashboard',
        `should navigate to dashboard view page`);
    } else {
      expect(false).toBe(true,
        `should have an element with class 'dashboard' in your pages.html`);
    }
  }));

  // it('should handle navigation to search view', fakeAsync(() => {
  //  // spyGetNewsbyText = spyOn(NewsService, 'GetNewsBytext').and.returnValue(of(testConfig.getNews.news));
  //  //let test = spyOn(component,"searchnews").and.callThrough();

  //   debugElement = fixture.debugElement.query(By.css('.search'));
  //   if (debugElement) {
  //     const searchtext = new FormControl('hello');
  //     component.txtSearch = searchtext;
  //     element = debugElement.nativeElement;
  //     element.click();      
  //     tick();
  //     expect(location.path()).toContain('/home/search/hello',
  //       `should navigate to search view page`);
  //   } else {
  //     expect(false).toBe(true,
  //       `should have an element with class 'search' in your pages.html`);
  //   }
  // }));

});
