import { NgModule } from '@angular/core';
import { routing } from './app.routes';
import { BootstrapModule } from './module/bootstrap/bootstrap.module';

import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';

import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { MatGridListModule, MatButtonToggleModule } from '@angular/material';
import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { PagesComponent } from './pages/pages.component';
import { FavouriteComponent } from './pages/favourite/favourite.component';
import { HeadlinesComponent } from './pages/headlines/headlines.component';
import { CatergoryComponent } from './pages/catergory/catergory.component';
import { SearchnewsComponent } from './pages/searchnews/searchnews.component';
import { NewscardComponent } from './pages/newscard/newscard.component';



@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,    
    LoginComponent,
    PagesComponent,
    DashboardComponent,
    FavouriteComponent,
    HeadlinesComponent,
    CatergoryComponent,
    RegistrationComponent,   
    SearchnewsComponent,
    NewscardComponent
  ],
  imports: [
    BootstrapModule,
    HttpClientModule,
    BrowserModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatInputModule,
    FlexLayoutModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatIconModule,
    MatToolbarModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatInputModule,
   // MatFormFieldModule,
    MatToolbarModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    //MatCardModule,
    MatListModule,
    MatButtonModule,
    MatDialogModule,
    MatSelectModule,
    BrowserModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
