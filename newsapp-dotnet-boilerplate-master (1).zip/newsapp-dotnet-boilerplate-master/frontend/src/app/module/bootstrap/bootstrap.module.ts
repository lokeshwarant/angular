import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BsDropdownModule, TooltipModule, ModalModule, CollapseModule } from 'ngx-bootstrap';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BsDropdownModule,
    TooltipModule,
    ModalModule,
    CollapseModule
  ],
  exports: [BsDropdownModule, TooltipModule, ModalModule, CollapseModule]
})
export class BootstrapModule { }
