import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { AuthenticationService } from './authentication.service'

@Injectable({
  providedIn: 'root'
})
export class NewsService {  

  constructor(private http: HttpClient, private authSvc:AuthenticationService) { }

  private extractData(res: Response) {
  let body = res;
  return body || { };
}

  endpoint = 'http://localhost:55375/news/';
  httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

  getheadlines(): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };

    return this.http.get(this.endpoint + 'allnews', httpOptions).pipe(
      map(this.extractData));
  }

  categorynews(text:string): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };

    return this.http.get(this.endpoint + 'newsbycategory' + '/' + text, httpOptions).pipe(
      map(this.extractData));
  }

  GetNewsBytext(text:string): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };
    
    return this.http.get(this.endpoint + 'newsbytext' + '/' + text, httpOptions).pipe(
      map(this.extractData));
  }
  
}
