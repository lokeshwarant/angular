import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { AuthenticationService } from './authentication.service'

@Injectable({
  providedIn: 'root'
})
export class FavouriteService {

  constructor(private http: HttpClient, private authSvc:AuthenticationService) { }

  private extractData(res: Response) {
  let body = res;
  return body || { };
}

  endpoint = 'http://localhost:49791/favourite/';
  httpOptions = {
  headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };

  getfavouritenews(): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };

    return this.http.get(this.endpoint + 'get' + '/', httpOptions).pipe(
      map(this.extractData));
  }

  createfavouritenews(data): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };

    return this.http.post(this.endpoint + 'create' + '/' , data, httpOptions);
  }

  deletefavouritenews(text:string): Observable<any> {
    const token = this.authSvc.getBearerToken();
    const httpOptions = {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    };

    return this.http.delete(this.endpoint + 'delete' + '/' + text, httpOptions);
  }
}
