import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';

import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { PagesComponent } from './pages/pages.component';
import { FavouriteComponent } from './pages/favourite/favourite.component';
import { HeadlinesComponent } from './pages/headlines/headlines.component';
import { SearchnewsComponent } from './pages/searchnews/searchnews.component';

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent},
    { path: 'register', component: RegistrationComponent},    
    {
        path: 'home',
        component: PagesComponent,
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'favourite', component : FavouriteComponent} ,
            { path: 'dashboard', component : DashboardComponent},
            { path: 'search/:searchtext', component : SearchnewsComponent}
        ]
    },
    { path: '**', component: PageNotFoundComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    // useHash: true
});

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})
export class AppModule { }
