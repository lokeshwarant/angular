﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavouriteService.Models
{
    public class FavouriteContext : DbContext, IFavouriteContext
    {
        public FavouriteContext() { }
        public FavouriteContext(DbContextOptions options) : base(options) { this.Database.EnsureCreated(); }
        
        public DbSet<FavouriteModel> Favourites { get; set; }
    }
}
