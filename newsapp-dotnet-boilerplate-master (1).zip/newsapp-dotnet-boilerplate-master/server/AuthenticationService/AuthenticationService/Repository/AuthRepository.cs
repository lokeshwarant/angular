﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;

namespace AuthenticationService.Repository
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IAuthenticationContext _context;

        public AuthRepository(IAuthenticationContext context)
        {
            _context = context;
        }

        public User FindUserById(string userId)
        {
            var _user = _context.Users.FirstOrDefault(u => u.UserId == userId);
            return _user;
        }

        public User LoginUser(string userId, string password)
        {
            var _user = _context.Users.FirstOrDefault(u => u.UserId == userId && u.Password == password);
            return _user;
        }

        public bool RegisterUser(User user)
        {
            var result = _context.Users.FirstOrDefault(u => u.UserId == user.UserId);

            if (result == null)
            {
                _context.Users.Add(user);
                _context.SaveChanges();

                return true;
            }
            else
                return false;
        }
    }
}
