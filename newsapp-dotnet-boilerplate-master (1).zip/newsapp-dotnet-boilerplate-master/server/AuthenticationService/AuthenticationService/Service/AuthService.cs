﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;
using AuthenticationService.Repository;
using AuthenticationService.Exceptions;

namespace AuthenticationService.Service
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository repository;
        
        public AuthService(IAuthRepository _repository)
        {
            this.repository = _repository;
        }
        public User LoginUser(string userId, string password)
        {
            var user = repository.LoginUser(userId, password);

            if (user != null)
            {
                return user;
            }
            else
            {                
                throw new UserNotFoundException($"User with this id {userId} and password {password} does not exist");
            }
        }

        public bool RegisterUser(User user)
        {
            var value = repository.RegisterUser(user);

            if (value)
            {
                return true;
            }
            else
            {
                throw new UserNotCreatedException($"User with this id {user.UserId} already exists");
            }
        }

        public bool IsUserExists(string userId)
        {
            var value = repository.FindUserById(userId);

            if (value != null)
                return true;
            else
                return false;
        }
    }
}
