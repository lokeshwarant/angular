﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;

namespace AuthenticationService.Models
{
    public class AuthenticationContext : DbContext, IAuthenticationContext
    {
        public AuthenticationContext() { }
        public AuthenticationContext(DbContextOptions options) : base(options) { this.Database.EnsureCreated(); }

        public DbSet<User> Users { get; set; }
    }
}
