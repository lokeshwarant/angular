﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Exceptions;
using Microsoft.AspNetCore.Mvc;

namespace AuthenticationService.Utility
{
    public class LoggingAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var type = context.Exception.GetType();
            var msg = context.Exception.Message;

            if (type == typeof(UserNotFoundException))
            {
                var value = new NotFoundObjectResult(msg);
                context.Result = value;
            }
            else if (type == typeof(UserNotCreatedException))
            {
                var value = new ConflictObjectResult(msg);
                context.Result = value;
            }
            else
            {
                var result = new StatusCodeResult(500);
                context.Result = result;
            }

           // base.OnException(context);
        }
    }

}
