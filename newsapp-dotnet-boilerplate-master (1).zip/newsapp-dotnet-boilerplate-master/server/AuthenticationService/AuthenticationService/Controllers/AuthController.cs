﻿using AuthenticationService.Utility;
using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Service;
using AuthServer.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IdentityModel.Tokens;

namespace AuthenticationService.Controllers
{
    [Logging]
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IAuthService service;
        private readonly ITokenGenerator tokengenerator;

        public AuthController(IAuthService objservice)
        {
            this.service = objservice;
            this.tokengenerator = new TokenGenerator();
        }

        // POST api/<controller>
        [HttpPost]
        [Route("register")]
        public IActionResult Register([FromBody]User user)
        {
           try
            { 
                return Created("",service.RegisterUser(user));
            }
            catch(UserNotCreatedException unf)
            {
                return new ConflictResult();
            }
            catch
            {
                return StatusCode(500, "Some server error");
            }
        }

        [HttpPost]
        [Route("login")]
        public IActionResult Login([FromBody]User user)
        {
            try
            {
                string userId = user.UserId;
                string password = user.Password;

                User _user = service.LoginUser(userId, password);
                string value = tokengenerator.GetJWTToken(user.UserId);

                return Ok(value);

            }
            catch( UserNotFoundException unf)
            {
                return new NotFoundResult();
            }
            catch(Exception ex)
            {
                return StatusCode(500, "Some server error");
            }

        }
    }
}
