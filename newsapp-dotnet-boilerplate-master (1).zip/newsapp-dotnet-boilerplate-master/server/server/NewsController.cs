﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace server
{
    [Route("news")]
    [Authorize]
    [Logging]
    public class NewsController : Controller
    {
        public readonly INewsService service;

        public NewsController(INewsService objvalue)
        {
            this.service = objvalue;
        }

        [Route("allnews")]
        [HttpGet]
        public IActionResult AllNews()
        {
            return Ok(service.AllNewsAsync());
        }

        [Route("newsbycategory/{text}")]
        [HttpGet]
        public IActionResult newsbycategory(String text)
        {
            return Ok(service.GetNewsByCategory(text));
        }

        [Route("newsbytext/{text}")]
        [HttpGet]
        public IActionResult newsbytext(String text)
        {
            return Ok(service.GetNewsBytext(text));
        }
        //875d9bec52f249f1b30631924f8e0e63
    }
}
