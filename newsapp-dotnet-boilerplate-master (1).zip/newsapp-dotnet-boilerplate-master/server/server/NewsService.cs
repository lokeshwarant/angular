﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using server.Exceptions;
using server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace server
{
    public class NewsService : INewsService
    {
        public List<NewsModel> AllNewsAsync()
        {
            Resultmodel objResult = new Resultmodel();
            string path = "https://newsapi.org/v2/top-headlines?country=us&apiKey=875d9bec52f249f1b30631924f8e0e63";

            using (var HttpClient = new HttpClient())
            {
                //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                var response = HttpClient.GetAsync(new Uri(path)).Result;

                object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);
               
                objResult = JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());

               
            }

            if (objResult.totalResults > 0 && objResult.status == "ok")
                return objResult.articles;
           else
                throw new NotFoundException("No Results found");
        }

        public List<NewsModel> GetNewsByCategory(String value)
        {
                string path = "https://newsapi.org/v2/top-headlines?apikey=875d9bec52f249f1b30631924f8e0e63&page=1&";

                path = path + "category=" + value ;

                using (var HttpClient = new HttpClient())
                {
                    //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                    var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                    var response = HttpClient.GetAsync(new Uri(path)).Result;

                    object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);
                    Resultmodel objResult = new Resultmodel();
                    objResult = JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());

                    if (objResult.totalResults > 0 && objResult.status == "ok")
                        return objResult.articles;
                    else
                        throw new NotFoundException("No Results found");
                }
            
        }

        public List<NewsModel> GetNewsBytext(String value)
        {
                string path = "https://newsapi.org/v2/everything?apikey=875d9bec52f249f1b30631924f8e0e63&page=1&language=en&";

                path = path + "q=" + value;

                using (var HttpClient = new HttpClient())
                {
                    //ttpClient.DefaultRequestHeaders.Add(RequestConstants.user)
                    var response1 = HttpClient.GetStringAsync(new Uri(path)).Result;
                    var response = HttpClient.GetAsync(new Uri(path)).Result;

                    object objValue = JsonConvert.DeserializeObject(HttpClient.GetStringAsync(new Uri(path)).Result);
                    Resultmodel objResult = new Resultmodel();
                    objResult = JsonConvert.DeserializeObject<Resultmodel>(objValue.ToString());

                    if (objResult.totalResults > 0 && objResult.status == "ok")
                        return objResult.articles;
                    else
                        throw new NotFoundException("No Results found");
                }
            
        }
    }
}
