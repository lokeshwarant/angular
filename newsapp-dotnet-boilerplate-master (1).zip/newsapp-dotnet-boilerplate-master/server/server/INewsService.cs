﻿using System.Collections.Generic;
using server.Models;

namespace server
{
    public interface INewsService
    {
        List<NewsModel> AllNewsAsync();
        List<NewsModel> GetNewsByCategory(string value);
        List<NewsModel> GetNewsBytext(string value);
    }
}