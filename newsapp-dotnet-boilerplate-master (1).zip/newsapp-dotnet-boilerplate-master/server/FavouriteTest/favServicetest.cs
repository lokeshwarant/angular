﻿using FavouriteService;
using FavouriteService.Models;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace FavouriteTest
{
    public class favServicetest: IClassFixture<DatabaseFixture>
    {
        private readonly IFavouriteService service;

        public favServicetest(DatabaseFixture _fixture)
        {
            service = new FavouriteService.FavouriteService(_fixture.context);
        }

       

        [Fact]
        public void CreateFavouriteShouldReturnTrue()
        {
            FavouriteModel objvalue = new FavouriteModel { id = "Nishant", title = "Nishant", content = "admin123", urlToImage = "9892134560"};

            var actual = service.CreateFavourite(objvalue);

            Assert.True(actual);
        }

        [Fact]
        public void DeleteFavouriteShouldReturnTrue()
        {
            string Id = "123";
            var actual = service.Deletefavourite(Id);

            Assert.True(actual);
        }

        [Fact]
        public void GetFavouritesShouldReturnlist()
        {
            var actual = service.GetFavourites();

            Assert.IsAssignableFrom<List<FavouriteModel>>(actual);
        }

        [Fact]
        public void DeleteFavouriteShouldThrowException()
        {
            var actual = Assert.Throws<NotFoundException>(() => service.Deletefavourite("174"));

            Assert.Equal("No records found", actual.Message);
        }
    }
}
