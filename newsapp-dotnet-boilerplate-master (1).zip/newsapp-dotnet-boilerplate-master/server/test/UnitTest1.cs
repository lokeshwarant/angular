using System;
using Xunit;
using server;
using server.Models;
using System.Collections.Generic;
using server.Exceptions;

namespace test
{
    public class UnitTest1
    {
        private readonly INewsService service;

        public UnitTest1()
        {
            this.service = new NewsService();
        }

        [Fact]
        public void AllNewsAsync()
        {
            var actual = service.AllNewsAsync();

            Assert.IsAssignableFrom<List<NewsModel>>(actual);
        }

        [Fact]
        public void GetNewsByCategory()
        {
            var actual = service.GetNewsByCategory("general");

            Assert.IsAssignableFrom<List<NewsModel>>(actual);
        }

        [Fact]
        public void GetNewsBytext()
        {
            var actual = service.GetNewsBytext("test");

            Assert.IsAssignableFrom<List<NewsModel>>(actual);
        }

        [Fact]
        public void GetNewsBytextShouldThrowException()
        {
            var actual = Assert.Throws<NotFoundException>(() => service.GetNewsByCategory("null"));

            Assert.Equal("No Results found", actual.Message);
        }
    }
}
